//
//  ViewController.swift
//  PeerSearch
//
//  Created by Piyush Sharma on 4/29/17.
//  Copyright © 2017 Piyush Sharma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var connections: UILabel!
    
    let peerService = PeerServiceManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        peerService.delegate = self
        
    }
    
    @IBAction func yellowTapped(_ sender: Any) {
        self.change(color: .yellow)
        let dictionary = ["color": "yellow", "value1": "1"]
        peerService.send(message: dictionary)
    }
    
    @IBAction func redTapped(_ sender: Any) {
        self.change(color: .red)
        let dictionary = ["color": "red", "value1": "2"]
        peerService.send(message: dictionary)
    }
    
    func change(color : UIColor) {
        UIView.animate(withDuration: 2) {
            self.view.backgroundColor = color
        }
    }
}

extension ViewController: PeerServiceManagerDelegate {
    
    func messageReceived(manager: PeerServiceManager, message: [String : Any]) {
        OperationQueue.main.addOperation {
            if let color = message["color"] as? String {
                switch color {
                case "red":
                    self.change(color: .red)
                case "yellow":
                    self.change(color: .yellow)
                default:
                    NSLog("%@", "Unknown color value received: \(color)")
                }
            }
        }
    }
    
    func connectedDevicesChanged(manager: PeerServiceManager, connectedDevices: [String]) {
        self.connections.text = "Connections: \(connectedDevices)"
    }
}

